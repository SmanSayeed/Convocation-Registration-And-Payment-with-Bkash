@extends('layouts.app')

@section('user_content')

<h1 style="color:#000;text-align:center">Edit Register</h1>

<?php $final_key = Auth::user()->final_key ?>
@if($final_key==1)

<div style="padding:30px">
<span><small>* required fields</small></span>
@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
<form action="edit-register" method="post" enctype="multipart/form-data">
		@csrf

		<table class="table">
			<tr>
				<td scope="row" class="text-color-black">First name *</td>
				<td scope="row"><input type="text" name="name" required value="{{ $data->username }}"></td>
			</tr>

			<tr>
				<td scope="row" class="text-color-black">Father's name *</td>
				<td scope="row"><input type="text" name="father" required value="{{ $data->father }}"></td>
			</tr>

			<tr>
				<td scope="row" class="text-color-black">Mother's name *</td>
				<td scope="row"><input type="text" name="mother" required value="{{ $data->mother }}"></td>
			</tr>

			<tr>
				<td scope="row" class="text-color-black">Hall *</td>
				<td scope="row">
					<select name="hall" required >
							<option selected="true" disabled="disabled">Choose hall</option>
							<option  value="Bangabandhu Hall">Bangabandhu Hall</option>
							<option  value="Shahid Dhirendranath Datta Hall">Shahid Dhirendranath Datta Hall</option>   
							<option  value="Kazi Nazrul Islam Hall">Kazi Nazrul Islam Hall</option>
							<option  value="Nawab Faizunnesa Chowdhurani Hall">Nawab Faizunnesa Chowdhurani Hall</option>
					</select>


				</td>
			</tr>

					<tr >
						<td scope="row" class="text-color-black">Select Faculty *</td>
						<td scope="row">
							
						<select name="faculty" id="faculty" required />
							<option selected="true" disabled="disabled">Choose Faculty</option>   
							<option id="f_science" value="Science">Science</option>
							<option id="f_arts" value="Arts">Arts</option>
							<option id="f_engineering" value="Engineering">Engineering</option>
						</select>

						</td>

					</tr>


									<tr id="d_engineering">
										<td scope="row" class="text-color-black">Select Department *</td>
											<td scope="row">
											<select name="dept" required />
											<option selected="true" disabled="disabled">Choose Department</option>  
												<option value="CSE">CSE</option>
												<option value="ICT">ICT</option>
									
											</select>
										</td>
									</tr>


									<tr id="d_arts">
										<td scope="row" class="text-color-black">Select Department *</td>
											<td scope="row">
											<select name="dept" required />
											<option selected="true" disabled="disabled">Choose Department</option>  
												<option value="Archeology">Archeology</option>
												<option value="English">English</option>
												<option value="Bangla">Bangla</option>
											</select>
										</td>
									</tr>



									<tr id="d_science">
										<td scope="row" class="text-color-black">Select Department *</td>
											<td scope="row">
											<select name="dept" required />
											<option selected="true" disabled="disabled">Choose Department *</option>  
												<option value="Math">Math</option>
												<option value="Chemistry">Chemistry</option>
												<option value="Physics">Physics</option>
											</select>
										</td>
									</tr>

			<tr>

				<td scope="row" class="text-color-black" >Obtained Degree for convocation *</td>
				<td scope="row"><input type="radio" name="degree" value="Bachelor's" id="bsc">Bachelor's<br>
				<input type="radio" name="degree" value="Master's" id="msc">Master's<br>
				<input type="radio" name="degree" value="Bachelor's and Master's" id="both">Both<br>

				</td>
			</tr>

			<tr id="bscsession">
				<td scope="row" class="text-color-black" >Session *</td>
				<td scope="row">
					<select name="sessionbsc" required>
						<option selected="true" disabled="disabled">Select Session (Bachelor's) *</option>
							<option  value="2006-2007">2006-2007</option>
							<option  value="2007-2008">2007-2008</option>
							<option  value="2008-2009">2008-2009</option>
							<option  value="2009-2010">2009-2010</option>
							<option  value="2010-2011">2010-2011</option>
							<option  value="2011-2012">2011-2012</option>
							<option  value="2012-2013">2012-2013</option>
							<option  value="2013-2014">2013-2014</option>
					</select>
				</td>
			</tr>

			<tr id="bscregistration">
				<td scope="row" class="text-color-black" required>Registration No (Bachelor's)*</td>
				<td scope="row"><input type="text" name="registrationnobsc" required value="{{ old('registrationno') }}"></td>
			</tr>

			<tr id="bscroll">
				<td scope="row" class="text-color-black" required>Roll No (Bachelor's)*</td>
				<td scope="row"><input type="text" name="rollnobsc" required value="{{ old('rollno') }}"></td>
			</tr>


		

			<tr id="bscresult">
				<td scope="row" class="text-color-black">Result of Bachelor's *</td>
				<td scope="row"><input type="text" name="resultbsc" value="{{ old('resultbsc') }}" ></td>
			</tr>

			<tr id="certificatebsc">
				<td>Have you collected your provisional certificate (Bachelor)? *</td>
			
				<td scope="row"><input type="radio" name="certificateb" value="2">Yes<br><input type="radio" name="certificateb" value="0">No<br>
				</td>
			</tr>

				<tr id="mscsession">
				<td scope="row" class="text-color-black" >Session *</td>
				<td scope="row">
					<select name="sessionmsc" required>
						<option selected="true" disabled="disabled">Select Session (Master's) *</option>
							<option  value="2006-2007">2006-2007</option>
							<option  value="2007-2008">2007-2008</option>
							<option  value="2008-2009">2008-2009</option>
							<option  value="2009-2010">2009-2010</option>
							<option  value="2010-2011">2010-2011</option>
							<option  value="2011-2012">2011-2012</option>
							<option  value="2012-2013">2012-2013</option>
							<option  value="2013-2014">2013-2014</option>
					</select>
				</td>
			</tr>

			<tr id="mscregistration">
				<td scope="row" class="text-color-black" required>Registration No (Master's)*</td>
				<td scope="row"><input type="text" name="registrationnomsc" required value="{{ old('registrationno') }}"></td>
			</tr>

			<tr id="mscroll">
				<td scope="row" class="text-color-black" required>Roll No (Master's)*</td>
				<td scope="row"><input type="text" name="rollnomsc" required value="{{ old('rollno') }}"></td>
			</tr>

			<tr id="mscresult">
				<td scope="row" class="text-color-black">Result of Master's *</td>
				<td scope="row"><input type="text" name="resultmsc" value="{{ old('resultmsc') }}" ></td>
			</tr>

	

			

			<tr id="certificatemsc">
				<td>Have you collected your provisional certificate (Master's)? *</td>
			
				<td scope="row"><input type="radio" name="certificatem" value="1">Yes<br><input type="radio" name="certificatem" value="0">No<br>
				</td>
			</tr>

			<tr>
				<td scope="row" class="text-color-black">Address(Mailing Address) *</td>
				<td scope="row"><input type="text" name="address" value="{{ old('address') }}"></td>
			</tr>

			<tr>
				<td scope="row" class="text-color-black">Current Affiliation(if any)</td>
				<td scope="row"><input type="text" name="job" value="{{ old('job') }}"></td>
			</tr>


			<tr>
				<td scope="row" class="text-color-black">Address(Mailing Address) *</td>
				<td scope="row"><input type="text" name="address" value="{{ $data->address }}"></td>
			</tr>

			<tr>
				<td scope="row" class="text-color-black">Current Affiliation(if any)</td>
				<td scope="row"><input type="text" name="job" value="{{ $data->job }}"></td>
			</tr>

		


			<tr>
				<td scope="row" class="text-color-black">Contact Mobile *</td>
				<td scope="row"><input type="text" name="mobile" required value="{{ $data->mobile }}" ></td>
			</tr>

			<tr>
				<td scope="row" class="text-color-black">Contact Email</td>
				<td scope="row"><input type="email" name="contactemail" value="{{ $data->contactemail }}" ></td>
			</tr>

				



			<tr>
				<td scope="row" class="text-color-black">Insert image<small>(max size 600x600 pixels and max memory 2MB)</small> *</td>
				<td scope="row"><input type="file" name="image" required></td>
				<td><a href="https://picresize.com/" target="_blank">Resize your image</a></td>
			</tr>				

			<tr>
				<td scope="row"></td>
				<td scope="row"><input type="submit" name="submit"></td>
			</tr>

		</table>

</form>

</div>

@endif



@endsection