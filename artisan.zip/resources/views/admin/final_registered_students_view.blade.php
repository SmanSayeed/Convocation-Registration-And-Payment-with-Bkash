@extends('admin.admin_master')
@section('admin_content')


	<table class="table">
			
			<tr>
				<th colspan="col">Name</th>
				<th colspan="col">Email</th>
				<th colspan="col">Username</th>
				<th colspan="col">Mobile</th>
				<th colspan="col">Faculty</th>
				<th colspan="col">Department</th>
				<th colspan="col">Image</th>
				<th colspan="col">Status</th>
				
			</tr>
@foreach($data as $d)
			<tr>
				<td>{{$d->username}}</td>
				<td>{{$d->mobile}}</td>
				<td>{{$d->name}}</td>
				<td>{{$d->faculty}}</td>
				<td>{{$d->dept}}</td>
				<td>{{$d->email}}</td>
				<td><img src="{{asset('student_images')}}/{{$d->image}}" height="150px" width="100px"></td>
				<td> <span style="color:red"> Not Verified </span></td>
			
			</tr>
@endforeach


	</table>

@endsection	