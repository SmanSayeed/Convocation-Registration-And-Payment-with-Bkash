@extends('admin_master')
@section('content')
	<div id="content" class="span10">
			
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="{{asset('admin')}}/index.html">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="{{asset('admin')}}/#">Dashboard</a></li>
			</ul>

			<div class="row-fluid">
				
				<div class="span3 statbox purple" onTablet="span6" onDesktop="span3">
					<div class="boxchart">5,6,7,2,0,4,2,4,8,2,3,3,2</div>
					<div class="number">854<i class="icon-arrow-up"></i></div>
					<div class="title">Registered Students</div>
					<div class="footer">
						<a href="{{asset('admin')}}/#"> read full report</a>
					</div>	
				</div>
				<div class="span3 statbox green" onTablet="span6" onDesktop="span3">
					<div class="boxchart">1,2,6,4,0,8,2,4,5,3,1,7,5</div>
					<div class="number">123<i class="icon-arrow-up"></i></div>
					<div class="title">Finally Registered for Convocation</div>
					<div class="footer">
						<a href="{{asset('admin')}}/#"> read full report</a>
					</div>
				</div>
				<div class="span3 statbox blue noMargin" onTablet="span6" onDesktop="span3">
					<div class="boxchart">5,6,7,2,0,-4,-2,4,8,2,3,3,2</div>
					<div class="number">982<i class="icon-arrow-up"></i></div>
					<div class="title">Approved Students</div>
					<div class="footer">
						<a href="{{asset('admin')}}/#"> read full report</a>
					</div>
				</div>
				<div class="span3 statbox yellow" onTablet="span6" onDesktop="span3">
					<div class="boxchart">7,2,2,2,1,-4,-2,4,8,,0,3,3,5</div>
					<div class="number">678<i class="icon-arrow-down"></i></div>
					<div class="title">Messages</div>
					<div class="footer">
						<a href="{{asset('admin')}}/#"> read full report</a>
					</div>
				</div>	
				
			</div>		

				
@endsection
       

	</div><!--/.fluid-container--> 