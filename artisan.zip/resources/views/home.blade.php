@extends('layouts.app')

@section('user_content')

@auth
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12" style="padding:30px">
            <div >
                <div class=" text-color-black"><h3>Final Registration And Pay For Convocation</h3></div>
            <hr>
           
            
                <div class=" text-color-black">
                  

                  
                   <a class="btn btn-lg btn-primary" href="{{route('student-final-register')}}">Final Registration for Convocation</a>


                </div>
            </div>
        </div>
    </div>
</div>
@endauth
@endsection
