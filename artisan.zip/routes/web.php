<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});





/* ========== ADMIN ============ */

Route::get('admin-login','adminController@login')->name('admin-login');

Route::get('admin-getdashboard','superAdminController@getdashboard')->name('admin-getdashboard');

Route::get('admin-logout','superAdminController@logout')->name('admin-logout');

Route::post('admin-dashboard','adminController@dashboard')->name('admin-dashboard');

Route::get('admin-registered-students','adminController@AdminRegisteredStudentsPage')->name('admin-registered-students');

Route::get('admin-final-registered-students','adminController@AdminFinalRegisteredStudentsPage')->name('admin-final-registered-students');

/* ADMIN END */




Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');





/* ========== Student ============ */


Route::get('student-dashboard','studentController@GetStudentDashboardPage')->name('student-dashboard');

Route::get('student-final-register','studentController@FinalRegisterpage')->name('student-final-register');


Route::get('student-view-register','studentController@FinalRegisterViewpage')->name('student-view-register');

Route::post('final-register','studentController@FinalRegistrationProcess')->name('final-register');

Route::get('student-edit-register','studentController@EditRegisterpage')->name('student-edit-register');

Route::post('edit-register','studentController@EditRegistrationProcess')->name('edit-register');

