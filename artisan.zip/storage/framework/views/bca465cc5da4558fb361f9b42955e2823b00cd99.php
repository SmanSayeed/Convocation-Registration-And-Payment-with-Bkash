<?php $__env->startSection('admin_content'); ?>


	<table class="table">
			
			<tr>
				<th colspan="col">Name</th>
				<th colspan="col">Email</th>
				
			</tr>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($d->name); ?></td>
				<td><?php echo e($d->email); ?></td>
			
			</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


	</table>

<?php $__env->stopSection(); ?>	
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\web\htdocs\cou convocation\laravel\yahoo\vu\resources\views/admin/registered_students_view.blade.php ENDPATH**/ ?>