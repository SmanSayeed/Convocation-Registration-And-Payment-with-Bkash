<?php $__env->startSection('user_content'); ?>

<?php if(auth()->guard()->check()): ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12" style="padding:30px">
            <div >
                <div class=" text-color-black"><h3>Final Registration And Pay For Convocation</h3></div>
            <hr>
           
            
                <div class=" text-color-black">
                  

                  
                   <a class="btn btn-lg btn-primary" href="<?php echo e(route('student-final-register')); ?>">Final Registration for Convocation</a>


                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\web\htdocs\cou convocation\laravel\yahoo\vu\resources\views/home.blade.php ENDPATH**/ ?>