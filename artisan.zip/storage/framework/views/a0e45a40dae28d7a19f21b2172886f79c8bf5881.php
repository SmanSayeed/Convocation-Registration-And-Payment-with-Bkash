<?php $__env->startSection('user_content'); ?>

<div style="padding:10px; margin-top:20px;">
<h2 style="color:black;">Registered Information</h2>
<br>
<br>

<table class="table">


<tr>		<th class="text-color-black" scope="row">  Image: </th>
	<td class="text-color-black" scope="row"> <img src="<?php echo e(asset('student_images')); ?>/<?php echo e($data->image); ?>" height="150px" width="100px"></td>
</tr>
<tr>
	<th  class="text-color-black" scope="row">Name: </th>
	<td class="text-color-black" scope="row"><?php echo e($data->username); ?></td>
</tr>
<tr>
	<th class="text-color-black" scope="row"> Father's name: </th>
	<td class="text-color-black" scope="row"><?php echo e($data->father); ?></td>
</tr>


<tr>
	<th class="text-color-black" scope="row"> Mother's name: </th>
	<td class="text-color-black" scope="row"><?php echo e($data->mother); ?></td>
</tr>

<tr>
	<th class="text-color-black" scope="row"> Hall: </th>
	<td class="text-color-black" scope="row"><?php echo e($data->hall); ?></td>
</tr>


<tr>
	<th class="text-color-black" scope="row"> Faculty: </th>
	<td class="text-color-black" scope="row"><?php echo e($data->faculty); ?></td>
</tr>
<tr>	<th class="text-color-black" scope="row"> Department: </th>
	<td class="text-color-black" scope="row"><?php echo e($data->dept); ?></td>	
</tr>
<?php if($data->resultbsc!='null'): ?>
<tr>
	<th class="text-color-black" scope="row"> Registration Number (Bachelor's): </th>
	<td class="text-color-black" scope="row"><?php echo e($data->registrationnobsc); ?></td>
</tr>

<tr>
	<th class="text-color-black" scope="row"> Roll No (Bachelor's): </th>
	<td class="text-color-black" scope="row"><?php echo e($data->rollnobsc); ?></td>
</tr>

<tr>
	<th class="text-color-black" scope="row"> Session (Bachelor's): </th>
	<td class="text-color-black" scope="row"><?php echo e($data->sessionbsc); ?></td>
</tr>

<tr>

	<th class="text-color-black" scope="row"> Result (Bachelor's): </th>

	<td class="text-color-black" scope="row"> <?php echo e($data->resultbsc); ?></td>

	
</tr>
<?php endif; ?>
<?php if($data->resultmsc!='null'): ?>
<tr>
	<th class="text-color-black" scope="row"> Registration Number (Master's): </th>
	<td class="text-color-black" scope="row"><?php echo e($data->registrationnomsc); ?></td>
</tr>

<tr>
	<th class="text-color-black" scope="row"> Roll No (Master's): </th>
	<td class="text-color-black" scope="row"><?php echo e($data->rollnomsc); ?></td>
</tr>

<tr>
	<th class="text-color-black" scope="row"> Session (Master's): </th>
	<td class="text-color-black" scope="row"><?php echo e($data->sessionmsc); ?></td>
</tr>
<tr>
	<th class="text-color-black" scope="row"> Result (Masters's): </th>

	<td class="text-color-black" scope="row"> <?php echo e($data->resultmsc); ?></td>

	
</tr>
<?php endif; ?>
<tr>
	<th class="text-color-black" scope="row"> Obtained Degree for Convcation : </th>

	<td class="text-color-black" scope="row"> <?php echo e($data->degree); ?></td>

	
</tr>



<tr>
	<th class="text-color-black" scope="row"> Have you collected your provisional certificate of BSC?: </th>
	<?php if($data->certificateb==2): ?><td class="text-color-black" scope="row">Yes</td><?php else: ?> <td class="text-color-black" scope="row">No</td> <?php endif; ?>

</tr>


<tr>
	<th class="text-color-black" scope="row"> Have you  collected your provisional certificate MSC?: </th>

	<?php if($data->certificatem==1): ?><td class="text-color-black" scope="row">Yes</td><?php else: ?> <td class="text-color-black" scope="row">No</td><?php endif; ?>
</tr>

<tr>
	<th class="text-color-black" scope="row"> Address: </th>
	<td class="text-color-black" scope="row"><?php echo e($data->address); ?></td>
</tr>


<tr>
	<th class="text-color-black" scope="row"> Current Job: </th>
	<td class="text-color-black" scope="row"><?php echo e($data->job); ?></td>
</tr>



<tr>
	<th class="text-color-black" scope="row"> Contact Number: </th>
	<td class="text-color-black" scope="row"><?php echo e($data->mobile); ?></td>
</tr>







</table>
</div>

<?php $__env->stopSection(); ?>	
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\web\htdocs\cou convocation\laravel\yahoo\vu\resources\views/student/view_register.blade.php ENDPATH**/ ?>