<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Comilla University Convocation 2019</title>

  <!-- Bootstrap core CSS -->
  <link href="<?php echo e(asset('user')); ?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="<?php echo e(asset('user')); ?>/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="<?php echo e(asset('user')); ?>/vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template -->
  <link href="<?php echo e(asset('user')); ?>/css/landing-page.css" rel="stylesheet">

  



</head>

<body style="
  font-family: Arial, Helvetica, sans-serif;">

  <!-- Navigation -->
  <nav class="navbar   static-top" style="background-color:#2F506C">
     <div class="container" >
      <a class="navbar-brand" href="#" style="color:white"></a>
      

    </div>
  </nav>

  <!-- Masthead -->


    <div class="container">
      <div class="row">

              <div class="col-md-4" style=" vertical-align: middle;  display:block;
    margin:10px auto;"><img src="<?php echo e(asset('user')); ?>/img/cou2.jpg" height="100" width="100px"></div>
                <div class="col-md-8" style=" text-align: center;
  vertical-align: middle;padding-top:30px;">
                  <h2 style="" > Comilla University First Convocation </h2>
                </div>

         
        </div>
       
      </div>
    </div>


  <div class="container-fluid p-0">
    
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color:#6091BA">

<div class="container">
  <a class="navbar-brand" href="#" style="margin-right:100px"></a>


  <div class=" navbar " id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">


    </ul>
    
  </div>


  <div class="navbar  w-100 order-3 dual">
  <!--
        <ul class="navbar-nav ml-auto" >

      <li class="nav-item active ">
        <a class="nav-link" href="<?php echo e(route('student-dashboard')); ?>">Home <span class="sr-only">(current)</span></a>
      </li>

            <li class="nav-item">
                <a class="nav-link" href="#" style="color:white">Notice</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#" style="color:white">Contact</a>
            </li>



<?php if(auth()->guard()->check()): ?>

  

          <li class="nav-item"   style="color:white">
      
          <a class="nav-link" href="#" style="color:white">Profile</a>
          </li>
          <li class="nav-item">
          <a class="nav-link" href="#" style="color:white">Edit Profile</a>
          </li>
          <li class="nav-item">
           <a class="nav-link" href="#" style="color:white">Change Password</a>
      </li>
      <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();" style="color:white">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
     
      </li>
      <?php endif; ?>
 <?php if(auth()->guard()->guest()): ?>
       <li class="nav-item active" style="color:white">
        <a class="nav-link" href="<?php echo e(route('login')); ?>">Login<span class="sr-only">(current)</span></a>
      </li>
<?php endif; ?>
        </ul>
        -->
    </div>


</nav>
</div>

  </div>

  <!-- Image Showcases -->
  <section class="showcase">
    <div class="container p-0">
      <div class="row no-gutters">





      <!-- ================================Main Content start============================= -->
<div class="col-lg-8 order-lg-2 text-white showcase-img" style="background-color:#fff">






        <!-- Login and Registration -->

<?php echo $__env->yieldContent('user_content'); ?>

<!-- ==Login Start== -->
    <!--      <div class="col-md-6">
              <h3 style="color:#000; margin:10px;padding:10px;">Login Now</h3>
            <hr> 
            <div class="login-form" style="padding:20px;">
              <form>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control"  placeholder="Enter email" name="email">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" class="form-control" placeholder="password must be 6 charecter" name="password">
                  </div>
                  
                  <button type="submit" class="btn btn-primary" name="login">Login</button>
              </form>
            </div>
          </div>
          -->
<!-- **Login End** -->

















<!-- ================================== Register start ================================= -->
<?php if(auth()->guard()->guest()): ?>
 <div class="row justify-content-center">
        <div class="col-md-8" style="padding:30px;">
            <div class="">
                <div class=""><h3 style="color:black">Register</h3></div>
<hr>
                <div class="">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right text-color-black"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-8">
                                <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label  class="col-md-4 col-form-label text-md-right text-color-black"><?php echo e(__('Mobile Number')); ?></label>

                            <div class="col-md-8">
                             
                                <input   class="form-control " name="email" value="<?php echo e(old('email')); ?>" required id="mobilenumber">

                                  <p id="mobilemsg" style="color:red"></p>
                                   <p id="mobilesuccess" style="color:green"></p>
                                     <span class="error" style="color: red; display: none">* Input digits (0 - 9)</span>
                                     <span><small style="color:blue">(Please Enter Your Mobile Number Carefully. This Number Will Be Considered As Your Login Id.)</small></span>
                             <!--    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> -->
                            </div>

                        </div>
                         <div class="form-group row">
                            <label  class="col-md-4 col-form-label text-md-right text-color-black"><?php echo e(__('Email')); ?> <small style="color:#ccc">(Optional)</small></label>

                            <div class="col-md-8">
                                <input   class="form-control " name="useremail" value="<?php echo e(old('useremail')); ?>" >
                               
                             <!--    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> -->
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right text-color-black"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-8">
                                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right text-color-black"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-8">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-success">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                    <br>
                    <hr>
                    <span style="color:black"> Already registered? </span>&nbsc;<a class="btn btn-sm btn-primary" href="<?php echo e(route('login')); ?>">Login Now</a>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<!-- **Register End************************************************ -->






       <!-- **Login and Register End** -->
    
        </div>  
      <!-- ***********************************Main Content End******************************* -->







        <!-- ================================Side bar start============================= -->
        <div class="col-lg-4   order-lg-1 " style="background-color:#6091BA;padding:10px;margin:20px 0px 20px;">
        <?php if(auth()->guard()->check()): ?>
          <h4>Dashboard of <?php echo e(Auth::user()->name); ?></h4>
          <hr>
           <ul class="list-group" style="margin-bottom:20px;" >
<?php $final_key = Auth::user()->final_key ?>
<?php if($final_key==0): ?>
           <li class="list-group-item"> 
                  <a class="nav-link " href="<?php echo e(route('student-final-register')); ?>" id="navbarDropdown" role="button" data="dropdown" aria-haspopup="true" aria-expanded="false">
                 Final Registration for Convocation
                </a>
            </li>
<?php elseif($final_key == 1): ?> 
           <li class="list-group-item"> 
                  <a class="nav-link " href="<?php echo e(route('student-view-register')); ?>" id="navbarDropdown" role="button" data="dropdown" aria-haspopup="true" aria-expanded="false">
                 View Your Registration 
                </a>
            </li>
            <li class="list-group-item"> 
                  <a class="nav-link " href="<?php echo e(route('student-edit-register')); ?>" id="navbarDropdown" role="button" data="dropdown" aria-haspopup="true" aria-expanded="false">
                 Edit Your Registration <small style="color:red"> (Till 5 January)</small>
                </a>
            </li>
            <li class="list-group-item ">
             <a class="nav-link " href="<?php echo e(route('student-final-register')); ?>" id="navbarDropdown" role="button" data="dropdown" aria-haspopup="true" aria-expanded="false">
                 Download Entry Card <small style="color:red"> (From 5 January)</small>
                </a>
            </li>
<?php endif; ?>
           <li class="list-group-item ">
          <a class="nav-link " href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();" >
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
     
      </li>

          </ul>
          <?php endif; ?>
          <h4>Notices</h4>
          <hr>
          <div class="myBox">
              <ul class="list-group"  >
            <li class="list-group-item">Registration process is going on</li>
            <li class="list-group-item">Download Admit Card from 5 january</li>
            <li class="list-group-item">List of Registered persons</li>
            <li class="list-group-item">Developers details</li>
          </ul>
          </div>
        
        </div>
        <!-- ***********************************Side bar End******************************* -->
      </div>
     
    </div>
  </section>

 


  <!-- Footer -->
  <footer class="footer " style="background-color:#6091BA">
    <div class="container">
      <div class="row">
        <div class="col-lg-6  text-center text-lg-left my-auto">
        
          <p class="" style="color:#fff;margin-top:20px;">&copy; Comilla University. All rights reserved</p>
          
        </div>
       
      </div>
    </div>
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="<?php echo e(asset('user')); ?>/vendor/jquery/jquery.min.js"></script>
  <script src="<?php echo e(asset('user')); ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>




<script type="text/javascript">
  
$(document).ready(function(){

     $("#d_engineering").hide();
     $("#d_arts").hide();
     $("#d_science").hide();

$("#faculty").change(function() {

  var selected_factulty_option = $('#faculty').val();

  if(selected_factulty_option==='Engineering') {
            $("#d_engineering").show();
               $("#d_arts").hide();
         $("#d_science").hide();
      } else if (selected_factulty_option==='Arts') {
            $("#d_arts").show();
                 $("#d_engineering").hide();
                 $("#d_science").hide();
      }
       else if (selected_factulty_option==='Science') {
            $("#d_science").show();
                 $("#d_engineering").hide();
           $("#d_arts").hide();
      }
});


          
});

</script>

<script type="text/javascript">
  $('input[name="degree"]').click(function(e) {
  if(e.target.value === "Bachelor's") {
    $('#bscresult').show();
    $('#mscresult').hide();

     $('#certificatebsc').show();
    $('#certificatemsc').hide();

      $('#bscsession').show();
    $('#mscsession').hide();

       $('#bscregistration').show();
    $('#mscregistration').hide();

      $('#bscroll').show();
    $('#mscroll').hide();

  }
  else if(e.target.value === "Master's"){
      $('#bscresult').hide();
    $('#mscresult').show();

      $('#certificatebsc').hide();
    $('#certificatemsc').show();

      $('#bscsession').hide();
    $('#mscsession').show();

       $('#bscregistration').hide();
    $('#mscregistration').show();

      $('#bscroll').hide();
    $('#mscroll').show();
  }
  else if(e.target.value === "Bachelor's and Master's"){
      $('#bscresult').show();
    $('#mscresult').show();


    $('#certificatebsc').show();
    $('#certificatemsc').show();

      $('#bscsession').show();
    $('#mscsession').show();

       $('#bscregistration').show();
    $('#mscregistration').show();

      $('#bscroll').show();
    $('#mscroll').show();
  }
   else {
     $('#bscresult').hide();
    $('#mscresult').hide();

    $('#certificatebsc').hide();
    $('#certificatemsc').hide();

      $('#bscsession').hide();
    $('#mscsession').hide();

       $('#bscregistration').hide();
    $('#mscregistration').hide();

      $('#bscroll').hide();
    $('#mscroll').hide();
  }
});
/*
    $('input[name="degree"]').click(function(e) {
  if(e.target.value === "Master's") {
    $('#bscresult').hide();
    $('#mscresult').show();
  } else {
     $('#bscresult').hide();
    $('#mscresult').hide();
  }
});


    $('input[name="degree"]').click(function(e) {
  if(e.target.value === "BSC and MSC") {
    $('#bscresult').show();
    $('#mscresult').show();
  } else {
     $('#bscresult').hide();
    $('#mscresult').hide();
  }
});
*/
     $('#certificatebsc').hide();
    $('#certificatemsc').hide();

    $('#bscresult').hide();
    $('#mscresult').hide();

     $('#bscsession').hide();
    $('#mscsession').hide();

       $('#bscregistration').hide();
    $('#mscregistration').hide();

      $('#bscroll').hide();
    $('#mscroll').hide();
</script>

<script type="text/javascript">
  jQuery(document).ready(function($){

       $("#mobilenumber").bind("keypress", function (e) {
          var keyCode = e.which ? e.which : e.keyCode
               
          if (!(keyCode >= 48 && keyCode <= 57)) {
            $(".error").css("display", "inline");
            return false;
          }else{
            $(".error").css("display", "none");
          }
      });

    $cf = $('#mobilenumber');
    $cf.blur(function(e){
        phone = $(this).val();
        phone = phone.replace(/[^0-9]/g,'');
        if (phone.length != 11)
        {

            $("#mobilemsg").text('Phone number must be 11 digits.');
            $('#mobilemsg').val('');
            $('#mobilemsg').focus();
        }else if (phone.length == 11){
          $("#mobilemsg").text('');
           $("#mobilesuccess").text('Perfect');
        }
    });
});
</script>

</body>

</html>
<?php /**PATH F:\web\htdocs\cou convocation\laravel\yahoo\vu\resources\views/layouts/app.blade.php ENDPATH**/ ?>