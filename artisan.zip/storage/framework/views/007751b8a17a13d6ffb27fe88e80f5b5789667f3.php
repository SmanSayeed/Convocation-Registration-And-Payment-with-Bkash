<?php $__env->startSection('admin_content'); ?>


	<table class="table">
			
			<tr>
				<th colspan="col">Name</th>
				<th colspan="col">Email</th>
				<th colspan="col">Username</th>
				<th colspan="col">Mobile</th>
				<th colspan="col">Faculty</th>
				<th colspan="col">Department</th>
				<th colspan="col">Image</th>
				<th colspan="col">Status</th>
				
			</tr>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($d->username); ?></td>
				<td><?php echo e($d->mobile); ?></td>
				<td><?php echo e($d->name); ?></td>
				<td><?php echo e($d->faculty); ?></td>
				<td><?php echo e($d->dept); ?></td>
				<td><?php echo e($d->email); ?></td>
				<td><img src="<?php echo e(asset('student_images')); ?>/<?php echo e($d->image); ?>" height="150px" width="100px"></td>
				<td> <span style="color:red"> Not Verified </span></td>
			
			</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


	</table>

<?php $__env->stopSection(); ?>	
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\web\htdocs\cou convocation\laravel\yahoo\vu\resources\views/admin/final_registered_students_view.blade.php ENDPATH**/ ?>