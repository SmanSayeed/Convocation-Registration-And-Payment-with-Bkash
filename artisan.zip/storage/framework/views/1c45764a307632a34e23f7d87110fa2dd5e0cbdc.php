<?php $__env->startSection('user_content'); ?>

 <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8" style="padding:30px">
            <div class="card">
                <div class=" text-color-black"><h3>Dashboard</h3></div>
                <hr>
                <div class=" text-color-black">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                   <h4> Hello <?php echo e(Auth::user()->name); ?>,</h4>
                   <a class="btn btn-lg btn-primary" href="<?php echo e(route('student-final-register')); ?>" style="margin-top:40px;">Final Register and pay for convocation</a>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\web\htdocs\cou convocation\laravel\yahoo\vu\resources\views/student/dashboard.blade.php ENDPATH**/ ?>